package com.dong.niit.service.impl;

import com.dong.niit.dao.TravelPlanMapper;
import com.dong.niit.pojo.TravelPlan;
import com.dong.niit.service.TravelPlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author: dongqihang
 * @Date: Created in 13:14 2018/9/6
 */
@Service
public class TravelPlanServiceImpl implements TravelPlanService{
    @Autowired
    private TravelPlanMapper travelPlanMapper;

    @Override
    public void insertTravelPlan(TravelPlan travelPlan) {
        travelPlanMapper.insert(travelPlan);
    }

    @Override
    public TravelPlan findTravelPlanById(Integer id) {
        return travelPlanMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<Object> findAllTravelPlan() {
        return travelPlanMapper.selectAll();
    }

    @Override
    public void updateTravelPlan(TravelPlan travelPlan) {
        travelPlanMapper.updateByPrimaryKey(travelPlan);
    }

    @Override
    public void deleteTravelPlan(Integer id) {
        travelPlanMapper.deleteByPrimaryKey(id);
    }
}
