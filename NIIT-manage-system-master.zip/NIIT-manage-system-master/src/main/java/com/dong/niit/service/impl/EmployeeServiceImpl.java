package com.dong.niit.service.impl;

import com.dong.niit.dao.EmployeeMapper;
import com.dong.niit.pojo.Employee;
import com.dong.niit.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author: dongqihang
 * @Date: Created in 13:13 2018/9/6
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {
    @Autowired
    private EmployeeMapper employeeMapper;

    @Override
    public void insertEmp(Employee employee) {
        employeeMapper.insert(employee);
    }

    @Override
    public Employee findEmpById(Integer id) {
        return employeeMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<Object> findAllEmp() {
        return employeeMapper.selectAll();
    }

    @Override
    public void updateEmp(Employee employee) {
        employeeMapper.updateByPrimaryKey(employee);
    }
}
