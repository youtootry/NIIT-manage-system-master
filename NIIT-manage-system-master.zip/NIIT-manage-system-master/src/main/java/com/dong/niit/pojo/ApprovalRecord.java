package com.dong.niit.pojo;

public class ApprovalRecord {
    private Integer approvalRecordId;

    private Integer sealApplyId;

    private String sealApplyResult;

    private String accountingStallView;

    private String accountingManagerView;

    public Integer getApprovalRecordId() {
        return approvalRecordId;
    }

    public void setApprovalRecordId(Integer approvalRecordId) {
        this.approvalRecordId = approvalRecordId;
    }

    public Integer getSealApplyId() {
        return sealApplyId;
    }

    public void setSealApplyId(Integer sealApplyId) {
        this.sealApplyId = sealApplyId;
    }

    public String getSealApplyResult() {
        return sealApplyResult;
    }

    public void setSealApplyResult(String sealApplyResult) {
        this.sealApplyResult = sealApplyResult == null ? null : sealApplyResult.trim();
    }

    public String getAccountingStallView() {
        return accountingStallView;
    }

    public void setAccountingStallView(String accountingStallView) {
        this.accountingStallView = accountingStallView == null ? null : accountingStallView.trim();
    }

    public String getAccountingManagerView() {
        return accountingManagerView;
    }

    public void setAccountingManagerView(String accountingManagerView) {
        this.accountingManagerView = accountingManagerView == null ? null : accountingManagerView.trim();
    }
}