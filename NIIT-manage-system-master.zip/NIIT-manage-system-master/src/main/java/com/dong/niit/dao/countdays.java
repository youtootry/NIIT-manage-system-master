package com.dong.niit.dao;

import java.util.Date;
/**
 * @Author: 王吉斌
 * @Date: 2018/9/7 11:30
 */
public class countdays {
    public static int twoday_cha(Date date1,Date date2){
        return (int)((date1.getTime()-date2.getTime())/(1000*3600*24));
    }
}
