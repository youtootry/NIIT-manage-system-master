package com.dong.niit.service;

import com.dong.niit.pojo.TravelPlan;

import java.util.List;

/**
 * @Author: dongqihang
 * @Date: Created in 13:14 2018/9/6
 */
public interface TravelPlanService {
    void insertTravelPlan(TravelPlan travelPlan);
    TravelPlan findTravelPlanById(Integer id);
    List<Object> findAllTravelPlan();
    void updateTravelPlan(TravelPlan travelPlan);
    void deleteTravelPlan(Integer id);
}
