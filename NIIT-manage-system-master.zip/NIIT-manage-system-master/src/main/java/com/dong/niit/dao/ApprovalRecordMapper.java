package com.dong.niit.dao;

import com.dong.niit.pojo.ApprovalRecord;

import java.util.List;

public interface ApprovalRecordMapper {
    int deleteByPrimaryKey(Integer approvalRecordId);

    int insert(ApprovalRecord record);

    int insertSelective(ApprovalRecord record);

    ApprovalRecord selectByPrimaryKey(Integer approvalRecordId);

    int updateByPrimaryKeySelective(ApprovalRecord record);

    int updateByPrimaryKey(ApprovalRecord record);

    List<Object> selectAll();
}