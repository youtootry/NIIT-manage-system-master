package com.dong.niit.dao;

import com.dong.niit.pojo.DepartmentInfo;

import java.util.List;

public interface DepartmentInfoMapper {
    int deleteByPrimaryKey(Integer departId);

    int insert(DepartmentInfo record);

    int insertSelective(DepartmentInfo record);

    DepartmentInfo selectByPrimaryKey(Integer departId);

    int updateByPrimaryKeySelective(DepartmentInfo record);

    int updateByPrimaryKey(DepartmentInfo record);

    List<Object> selectAll();
}