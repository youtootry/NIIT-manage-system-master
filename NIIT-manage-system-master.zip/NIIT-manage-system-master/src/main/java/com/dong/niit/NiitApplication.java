package com.dong.niit;

import org.apache.ibatis.annotations.Mapper;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@MapperScan("com.dong.niit.dao")
@SpringBootApplication
public class NiitApplication {

	public static void main(String[] args) {
		SpringApplication.run(NiitApplication.class, args);
	}
}
