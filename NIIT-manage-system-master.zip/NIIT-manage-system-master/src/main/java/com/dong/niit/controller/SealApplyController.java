package com.dong.niit.controller;

import com.dong.niit.pojo.SealApply;
import com.dong.niit.service.SealApplyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
/**
 * @Author: 王吉斌
 * @Date: 2018/9/7 11:30
 */
@RestController
@RequestMapping("/sealapply")
public class SealApplyController {
    @Autowired
    private SealApplyService sealApplyService;
    DateFormat format=new SimpleDateFormat("yyyy-MM-dd");
    @RequestMapping(value = "/findbyid",method = RequestMethod.POST)
    public Object findById(@RequestParam("id") int id){
        return sealApplyService.findSealApplyById(id);
    }
    @RequestMapping(value = "/findall",method = RequestMethod.POST)
    public List<Object> findAll(){
        return sealApplyService.findAllSealApply();
    }
    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public String insert(@RequestParam("applydetails") String  applydetails, @RequestParam("sealtype") int sealtype, @RequestParam("applydate") String applydate,@RequestParam("applyfinancialstaff") String  applyfinancialstaff){
        SealApply sealApply=new SealApply();
        sealApply.setApplyEmployeeId(2);
        sealApply.setApplyDetails(applydetails);
        sealApply.setSealType(sealtype);
        try {
            sealApply.setApplyDate(format.parse(applydate));
        }
        catch (ParseException e){
            e.printStackTrace();
        }
        sealApply.setApplyFinancialStaff(applyfinancialstaff);
        sealApplyService.insertSealApply(sealApply);
        return "success";
    }
    @RequestMapping(value = "/update",method = RequestMethod.POST)
    public String updateById(@RequestParam("applyid") int applyid,@RequestParam("applydetails") String  applydetails,@RequestParam("sealtype") int sealtype,@RequestParam("applydate") String applydate,@RequestParam("applyfinancialstaff") String  applyfinancialstaff){

        SealApply sealApply=new SealApply();
        sealApply.setApplyId(applyid);
        sealApply.setApplyEmployeeId(2);
        sealApply.setApplyDetails(applydetails);
        sealApply.setSealType(sealtype);
        try {
            sealApply.setApplyDate(format.parse(applydate));
        }
        catch (ParseException e){
            e.printStackTrace();
        }
        sealApply.setApplyFinancialStaff(applyfinancialstaff);
        sealApplyService.updateSealApply(sealApply);
        return "success";
    }
}
