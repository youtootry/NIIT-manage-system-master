package com.dong.niit.controller;

import com.dong.niit.dao.countdays;
import com.dong.niit.pojo.TravelPlan;
import com.dong.niit.service.TravelPlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
/**
 * @Author: 王吉斌
 * @Date: 2018/9/7 11:30
 */
@RestController
@RequestMapping(value = "/travelplan")
public class TravelPlanController {
    @Autowired
    TravelPlanService travelPlanService;
    DateFormat format=new SimpleDateFormat("yyyy-MM-dd");
    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public String addTravelPlan(@RequestParam("travelplanmonth") String travelplanmonth,
                                @RequestParam("travelplanfromdate") String travelplanfromdate,
                                @RequestParam("travelplantodate") String travelplantodate,
                                @RequestParam("travelplancity") String travelplancity,
                                @RequestParam("travelplancustomer") String travelplancustomer,
                                @RequestParam("travelplantbusinesstype") String travelplantbusinesstype,
                                @RequestParam("travelplanreason") String travelplanreason,
                                @RequestParam("travelplantravelmode") String travelplantravelmode,
                                @RequestParam("travelplanticketcost") BigDecimal travelplanticketcost,
                                @RequestParam("travelplandaycost") BigDecimal travelplandaycost
                                ){

        try{
            Date date1=format.parse(travelplanfromdate);
            Date date2=format.parse(travelplantodate);
            TravelPlan travelPlan=new TravelPlan();
            travelPlan.setTravelEmployeeId(2);
            travelPlan.setTravelPlanMonth(travelplanmonth);
            travelPlan.setTravelPlanFromdate(date1);
            travelPlan.setTravelPlanTodate(date2);
            travelPlan.setTravelPlanCity(travelplancity);
            travelPlan.setTravelPlanCustomer(travelplancustomer);
            travelPlan.setTravelPlanBusinesstype(travelplantbusinesstype);
            travelPlan.setTravelPlanReason(travelplanreason);
            travelPlan.setTravelPlanTravelmode(travelplantravelmode);
            travelPlan.setTravelPlanTicketcost(travelplanticketcost);
            travelPlan.setTravelPlanDaycost(travelplandaycost);
            int daycha=countdays.twoday_cha(date2, date1);
            int daycost=travelplandaycost.intValue();
            int total=daycha*daycost+travelplanticketcost.intValue();
            travelPlan.setTravelPlanTotalcost(BigDecimal.valueOf(total));
            travelPlanService.insertTravelPlan(travelPlan);
        }catch (ParseException e){
            e.printStackTrace();
        }

        return "success";
    }
    @RequestMapping(value = "/update",method = RequestMethod.POST)
    public String updateTrave(@RequestParam("id") int id,
                              @RequestParam("travelplanmonth") String travelplanmonth,
                              @RequestParam("travelplanfromdate") String travelplanfromdate,
                              @RequestParam("travelplantodate") String travelplantodate,
                              @RequestParam("travelplancity") String travelplancity,
                              @RequestParam("travelplancustomer") String travelplancustomer,
                              @RequestParam("travelplantbusinesstype") String travelplantbusinesstype,
                              @RequestParam("travelplanreason") String travelplanreason,
                              @RequestParam("travelplantravelmode") String travelplantravelmode,
                              @RequestParam("travelplanticketcost") BigDecimal travelplanticketcost,
                              @RequestParam("travelplandaycost") BigDecimal travelplandaycost){
        try{
        Date date1=format.parse(travelplanfromdate);
        Date date2=format.parse(travelplantodate);
        TravelPlan travelPlan=new TravelPlan();
        travelPlan.setTravelPlanId(id);
        travelPlan.setTravelEmployeeId(2);
        travelPlan.setTravelPlanMonth(travelplanmonth);
        travelPlan.setTravelPlanFromdate(date1);
        travelPlan.setTravelPlanTodate(date2);
        travelPlan.setTravelPlanCity(travelplancity);
        travelPlan.setTravelPlanCustomer(travelplancustomer);
        travelPlan.setTravelPlanBusinesstype(travelplantbusinesstype);
        travelPlan.setTravelPlanReason(travelplanreason);
        travelPlan.setTravelPlanTravelmode(travelplantravelmode);
        travelPlan.setTravelPlanTicketcost(travelplanticketcost);
        travelPlan.setTravelPlanDaycost(travelplandaycost);
        int daycha=countdays.twoday_cha(date2, date1);
        int daycost=travelplandaycost.intValue();
        int total=daycha*daycost+travelplanticketcost.intValue();
        travelPlan.setTravelPlanTotalcost(BigDecimal.valueOf(total));
        travelPlanService.updateTravelPlan(travelPlan);
        }catch (ParseException e){
            e.printStackTrace();
        }

        return "success";
    }
    @RequestMapping(value = "/delete",method = RequestMethod.POST)
    public String deleteTravel(@RequestParam("id") int id){
        travelPlanService.deleteTravelPlan(id);
        return "success";
    }
}
