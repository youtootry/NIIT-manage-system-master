package com.dong.niit.service;

import com.dong.niit.pojo.PositionInfo;

import java.util.List;

/**
 * @Author: dongqihang
 * @Date: Created in 13:13 2018/9/6
 */
public interface PositionInfoService {
    void insertPosition(PositionInfo positionInfo);
    PositionInfo findPositionById(Integer id);
    List<Object> findAllPosition();
    void updatePosition(PositionInfo positionInfo);
}
