package com.dong.niit.controller;

import com.dong.niit.service.PositionInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
/**
 * @Author: 王吉斌
 * @Date: 2018/9/7 11:30
 */
@RestController
@RequestMapping(value = "/positioninfo")
public class PositionInfoController {
    @Autowired
    private PositionInfoService positionInfoService;

    @RequestMapping(value = "/findbyid",method = RequestMethod.POST)
    public Object findById(@RequestParam("id") int id){
        return positionInfoService.findPositionById(id);
    }
}
