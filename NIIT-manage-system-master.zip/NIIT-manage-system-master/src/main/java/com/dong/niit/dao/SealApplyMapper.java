package com.dong.niit.dao;

import com.dong.niit.pojo.SealApply;

import java.util.List;

public interface SealApplyMapper {
    int deleteByPrimaryKey(Integer applyId);

    int insert(SealApply record);

    int insertSelective(SealApply record);

    SealApply selectByPrimaryKey(Integer applyId);

    int updateByPrimaryKeySelective(SealApply record);

    int updateByPrimaryKey(SealApply record);

    List<Object> selectAll();
}