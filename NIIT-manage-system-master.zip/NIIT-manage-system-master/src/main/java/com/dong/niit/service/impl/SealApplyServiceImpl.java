package com.dong.niit.service.impl;

import com.dong.niit.dao.SealApplyMapper;
import com.dong.niit.pojo.SealApply;
import com.dong.niit.service.SealApplyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author: dongqihang
 * @Date: Created in 13:14 2018/9/6
 */
@Service
public class SealApplyServiceImpl implements SealApplyService {
    @Autowired
    private SealApplyMapper sealApplyMapper;

    @Override
    public void insertSealApply(SealApply sealApply) {
        sealApplyMapper.insert(sealApply);
    }

    @Override
    public SealApply findSealApplyById(Integer id) {
        return sealApplyMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<Object> findAllSealApply() {
        return sealApplyMapper.selectAll();
    }

    @Override
    public void updateSealApply(SealApply sealApply) {
        sealApplyMapper.updateByPrimaryKey(sealApply);
    }
}
