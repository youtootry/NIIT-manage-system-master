package com.dong.niit.pojo;

public class Employee {
    private Integer employeeId;

    private String employeeName;

    private String employeeGender;

    private String employeeAge;

    private String employeePhone;

    private String employeeEmail;

    private Integer employeeType;

    private Integer departInfoId;

    private Integer positionInfoId;

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName == null ? null : employeeName.trim();
    }

    public String getEmployeeGender() {
        return employeeGender;
    }

    public void setEmployeeGender(String employeeGender) {
        this.employeeGender = employeeGender == null ? null : employeeGender.trim();
    }

    public String getEmployeeAge() {
        return employeeAge;
    }

    public void setEmployeeAge(String employeeAge) {
        this.employeeAge = employeeAge == null ? null : employeeAge.trim();
    }

    public String getEmployeePhone() {
        return employeePhone;
    }

    public void setEmployeePhone(String employeePhone) {
        this.employeePhone = employeePhone == null ? null : employeePhone.trim();
    }

    public String getEmployeeEmail() {
        return employeeEmail;
    }

    public void setEmployeeEmail(String employeeEmail) {
        this.employeeEmail = employeeEmail == null ? null : employeeEmail.trim();
    }

    public Integer getEmployeeType() {
        return employeeType;
    }

    public void setEmployeeType(Integer employeeType) {
        this.employeeType = employeeType;
    }

    public Integer getDepartInfoId() {
        return departInfoId;
    }

    public void setDepartInfoId(Integer departInfoId) {
        this.departInfoId = departInfoId;
    }

    public Integer getPositionInfoId() {
        return positionInfoId;
    }

    public void setPositionInfoId(Integer positionInfoId) {
        this.positionInfoId = positionInfoId;
    }
}