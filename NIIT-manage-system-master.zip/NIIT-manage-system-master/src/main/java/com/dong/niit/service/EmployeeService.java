package com.dong.niit.service;

import com.dong.niit.pojo.Employee;

import java.util.List;

/**
 * @Author: dongqihang
 * @Date: Created in 13:13 2018/9/6
 */
public interface EmployeeService {
    void insertEmp(Employee employee);
    Employee findEmpById(Integer id);
    List<Object> findAllEmp();
    void updateEmp(Employee employee);
}
