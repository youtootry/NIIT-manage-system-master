package com.dong.niit.controller;

import com.dong.niit.pojo.ApprovalRecord;
import com.dong.niit.service.ApprovalRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @Author: dongqihang
 * @Date: Created in 14:57 2018/9/6
 */
@RestController
@RequestMapping(value = "/approvalrecord")
public class ApprovalRecordController {
    @Autowired
    private ApprovalRecordService approvalRecordService;

    @RequestMapping(value = "/insert", method = RequestMethod.GET)
    public String insert(@RequestParam("id") int id, @RequestParam("result") String result){
        ApprovalRecord approvalRecord = new ApprovalRecord();
        approvalRecord.setSealApplyId(id);
        approvalRecord.setSealApplyResult(result);
        approvalRecordService.insertApprovalRecord(approvalRecord);
        return "success";
    }

    @RequestMapping(value = "/findbyid", method = RequestMethod.GET)
    public Object findById(@RequestParam("id") int id){
        return approvalRecordService.findApprovalRecordById(id);
    }

    @RequestMapping(value = "/findall", method = RequestMethod.GET)
    public List<Object> findAll(){
        return approvalRecordService.findAllApprovalRecord();
    }

    @RequestMapping(value = "/update", method = RequestMethod.GET)
    public String updateById(@RequestParam("id") int id,@RequestParam("result") String result){
        ApprovalRecord approvalRecord = new ApprovalRecord();
        approvalRecord.setSealApplyResult(result);
        approvalRecord.setApprovalRecordId(id);
        approvalRecordService.updateApprovalRecord(approvalRecord);
        return "success";
    }
}
