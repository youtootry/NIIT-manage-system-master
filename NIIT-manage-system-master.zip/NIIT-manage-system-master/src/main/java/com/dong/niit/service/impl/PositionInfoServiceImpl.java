package com.dong.niit.service.impl;

import com.dong.niit.dao.PositionInfoMapper;
import com.dong.niit.pojo.PositionInfo;
import com.dong.niit.service.PositionInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author: dongqihang
 * @Date: Created in 13:14 2018/9/6
 */
@Service
public class PositionInfoServiceImpl implements PositionInfoService{
    @Autowired
    private PositionInfoMapper positionInfoMapper;

    @Override
    public void insertPosition(PositionInfo positionInfo) {
        positionInfoMapper.insert(positionInfo);
    }

    @Override
    public PositionInfo findPositionById(Integer id) {
        return positionInfoMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<Object> findAllPosition() {
        return positionInfoMapper.selectAll();
    }

    @Override
    public void updatePosition(PositionInfo positionInfo) {
        positionInfoMapper.updateByPrimaryKey(positionInfo);
    }
}
