package com.dong.niit.service;

import com.dong.niit.pojo.SealApply;

import java.util.List;

/**
 * @Author: dongqihang
 * @Date: Created in 13:14 2018/9/6
 */
public interface SealApplyService {
    void insertSealApply(SealApply sealApply);
    SealApply findSealApplyById(Integer id);
    List<Object> findAllSealApply();
    void updateSealApply(SealApply sealApply);
}
