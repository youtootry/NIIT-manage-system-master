package com.dong.niit.dao;

import com.dong.niit.pojo.TravelPlan;

import java.util.List;

public interface TravelPlanMapper {
    int deleteByPrimaryKey(Integer travelPlanId);

    int insert(TravelPlan record);

    int insertSelective(TravelPlan record);

    TravelPlan selectByPrimaryKey(Integer travelPlanId);

    int updateByPrimaryKeySelective(TravelPlan record);

    int updateByPrimaryKey(TravelPlan record);

    List<Object> selectAll();
}