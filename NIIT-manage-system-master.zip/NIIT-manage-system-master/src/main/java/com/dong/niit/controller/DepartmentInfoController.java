package com.dong.niit.controller;

import com.dong.niit.service.DepartmentInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
/**
 * @Author: 王吉斌
 * @Date: 2018/9/7 11:30
 */
@RestController
@RequestMapping(value = "/departmentinfo")
public class DepartmentInfoController {
    @Autowired
    private DepartmentInfoService departmentInfoService;


    @RequestMapping(value = "/findall", method = RequestMethod.POST)
    public List<Object> findAll(){
        return departmentInfoService.findAllDep();
    }
}
