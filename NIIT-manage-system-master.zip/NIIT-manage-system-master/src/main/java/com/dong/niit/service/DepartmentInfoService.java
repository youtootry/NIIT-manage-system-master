package com.dong.niit.service;

import com.dong.niit.pojo.DepartmentInfo;

import java.util.List;

/**
 * @Author: dongqihang
 * @Date: Created in 13:13 2018/9/6
 */
public interface DepartmentInfoService {
    void insertDep(DepartmentInfo departmentInfo);
    DepartmentInfo findDepById(Integer id);
    List<Object> findAllDep();
    void updateDep(DepartmentInfo departmentInfo);
}
