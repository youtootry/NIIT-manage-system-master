package com.dong.niit.controller;

import com.dong.niit.dao.EmployeeMapper;
import com.dong.niit.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
/**
 * @Author: 王吉斌
 * @Date: 2018/9/7 11:30
 */
@RestController
@RequestMapping(value = "/employee")
public class EmployeeController {
    @Autowired
    private EmployeeService employeeService;

    @RequestMapping(value = "/findbyid",method = RequestMethod.POST)
    public Object findByid(@RequestParam("id") int id){
        return employeeService.findEmpById(id);
    }
}
