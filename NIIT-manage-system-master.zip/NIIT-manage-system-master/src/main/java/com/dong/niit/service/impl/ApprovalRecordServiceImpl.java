package com.dong.niit.service.impl;


import com.dong.niit.dao.ApprovalRecordMapper;
import com.dong.niit.pojo.ApprovalRecord;
import com.dong.niit.service.ApprovalRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author: dongqihang
 * @Date: Created in 13:12 2018/9/6
 */
@Service
public class ApprovalRecordServiceImpl implements ApprovalRecordService {
    @Autowired
    private ApprovalRecordMapper approvalRecordMapper;

    @Override
    public void insertApprovalRecord(ApprovalRecord approvalRecord) {
        approvalRecordMapper.insert(approvalRecord);
    }

    @Override
    public ApprovalRecord findApprovalRecordById(Integer id) {
        return approvalRecordMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<Object> findAllApprovalRecord() {
        return approvalRecordMapper.selectAll();
    }

    @Override
    public void updateApprovalRecord(ApprovalRecord approvalRecord) {
        approvalRecordMapper.updateByPrimaryKey(approvalRecord);
    }
}
