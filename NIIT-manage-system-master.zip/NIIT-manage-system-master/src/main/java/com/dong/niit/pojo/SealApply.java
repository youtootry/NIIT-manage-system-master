package com.dong.niit.pojo;

import java.util.Date;

public class SealApply {
    private Integer applyId;

    private Integer applyEmployeeId;

    private String applyDetails;

    private Integer sealType;

    private Date applyDate;

    private String applyFinancialStaff;

    public Integer getApplyId() {
        return applyId;
    }

    public void setApplyId(Integer applyId) {
        this.applyId = applyId;
    }

    public Integer getApplyEmployeeId() {
        return applyEmployeeId;
    }

    public void setApplyEmployeeId(Integer applyEmployeeId) {
        this.applyEmployeeId = applyEmployeeId;
    }

    public String getApplyDetails() {
        return applyDetails;
    }

    public void setApplyDetails(String applyDetails) {
        this.applyDetails = applyDetails == null ? null : applyDetails.trim();
    }

    public Integer getSealType() {
        return sealType;
    }

    public void setSealType(Integer sealType) {
        this.sealType = sealType;
    }

    public Date getApplyDate() {
        return applyDate;
    }

    public void setApplyDate(Date applyDate) {
        this.applyDate = applyDate;
    }

    public String getApplyFinancialStaff() {
        return applyFinancialStaff;
    }

    public void setApplyFinancialStaff(String applyFinancialStaff) {
        this.applyFinancialStaff = applyFinancialStaff == null ? null : applyFinancialStaff.trim();
    }
}