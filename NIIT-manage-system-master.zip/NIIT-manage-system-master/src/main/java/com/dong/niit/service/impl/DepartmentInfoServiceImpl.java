package com.dong.niit.service.impl;

import com.dong.niit.dao.DepartmentInfoMapper;
import com.dong.niit.pojo.DepartmentInfo;
import com.dong.niit.service.DepartmentInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author: dongqihang
 * @Date: Created in 13:13 2018/9/6
 */
@Service
public class DepartmentInfoServiceImpl implements DepartmentInfoService {
    @Autowired
    private DepartmentInfoMapper departmentInfoMapper;

    @Override
    public void insertDep(DepartmentInfo departmentInfo) {
        departmentInfoMapper.insert(departmentInfo);
    }

    @Override
    public DepartmentInfo findDepById(Integer id) {
        return departmentInfoMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<Object> findAllDep() {
        return departmentInfoMapper.selectAll();
    }

    @Override
    public void updateDep(DepartmentInfo departmentInfo) {
        departmentInfoMapper.updateByPrimaryKey(departmentInfo);
    }
}
