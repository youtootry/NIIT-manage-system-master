package com.dong.niit.pojo;

import java.math.BigDecimal;
import java.util.Date;

public class TravelPlan {
    private Integer travelPlanId;

    private Integer travelEmployeeId;

    private String travelPlanMonth;

    private Date travelPlanFromdate;

    private Date travelPlanTodate;

    private String travelPlanCity;

    private String travelPlanCustomer;

    private String travelPlanBusinesstype;

    private String travelPlanReason;

    private String travelPlanTravelmode;

    private BigDecimal travelPlanTicketcost;

    private BigDecimal travelPlanDaycost;

    private BigDecimal travelPlanTotalcost;

    public Integer getTravelPlanId() {
        return travelPlanId;
    }

    public void setTravelPlanId(Integer travelPlanId) {
        this.travelPlanId = travelPlanId;
    }

    public Integer getTravelEmployeeId() {
        return travelEmployeeId;
    }

    public void setTravelEmployeeId(Integer travelEmployeeId) {
        this.travelEmployeeId = travelEmployeeId;
    }

    public String getTravelPlanMonth() {
        return travelPlanMonth;
    }

    public void setTravelPlanMonth(String travelPlanMonth) {
        this.travelPlanMonth = travelPlanMonth == null ? null : travelPlanMonth.trim();
    }

    public Date getTravelPlanFromdate() {
        return travelPlanFromdate;
    }

    public void setTravelPlanFromdate(Date travelPlanFromdate) {
        this.travelPlanFromdate = travelPlanFromdate;
    }

    public Date getTravelPlanTodate() {
        return travelPlanTodate;
    }

    public void setTravelPlanTodate(Date travelPlanTodate) {
        this.travelPlanTodate = travelPlanTodate;
    }

    public String getTravelPlanCity() {
        return travelPlanCity;
    }

    public void setTravelPlanCity(String travelPlanCity) {
        this.travelPlanCity = travelPlanCity == null ? null : travelPlanCity.trim();
    }

    public String getTravelPlanCustomer() {
        return travelPlanCustomer;
    }

    public void setTravelPlanCustomer(String travelPlanCustomer) {
        this.travelPlanCustomer = travelPlanCustomer == null ? null : travelPlanCustomer.trim();
    }

    public String getTravelPlanBusinesstype() {
        return travelPlanBusinesstype;
    }

    public void setTravelPlanBusinesstype(String travelPlanBusinesstype) {
        this.travelPlanBusinesstype = travelPlanBusinesstype == null ? null : travelPlanBusinesstype.trim();
    }

    public String getTravelPlanReason() {
        return travelPlanReason;
    }

    public void setTravelPlanReason(String travelPlanReason) {
        this.travelPlanReason = travelPlanReason == null ? null : travelPlanReason.trim();
    }

    public String getTravelPlanTravelmode() {
        return travelPlanTravelmode;
    }

    public void setTravelPlanTravelmode(String travelPlanTravelmode) {
        this.travelPlanTravelmode = travelPlanTravelmode == null ? null : travelPlanTravelmode.trim();
    }

    public BigDecimal getTravelPlanTicketcost() {
        return travelPlanTicketcost;
    }

    public void setTravelPlanTicketcost(BigDecimal travelPlanTicketcost) {
        this.travelPlanTicketcost = travelPlanTicketcost;
    }

    public BigDecimal getTravelPlanDaycost() {
        return travelPlanDaycost;
    }

    public void setTravelPlanDaycost(BigDecimal travelPlanDaycost) {
        this.travelPlanDaycost = travelPlanDaycost;
    }

    public BigDecimal getTravelPlanTotalcost() {
        return travelPlanTotalcost;
    }

    public void setTravelPlanTotalcost(BigDecimal travelPlanTotalcost) {
        this.travelPlanTotalcost = travelPlanTotalcost;
    }
}