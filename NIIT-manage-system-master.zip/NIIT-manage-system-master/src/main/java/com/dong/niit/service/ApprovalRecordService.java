package com.dong.niit.service;

import com.dong.niit.pojo.ApprovalRecord;

import java.util.List;

/**
 * @Author: dongqihang
 * @Date: Created in 13:12 2018/9/6
 */
public interface ApprovalRecordService {
    void insertApprovalRecord(ApprovalRecord approvalRecord);
    ApprovalRecord findApprovalRecordById(Integer id);
    List<Object> findAllApprovalRecord();
    void updateApprovalRecord(ApprovalRecord approvalRecord);
}
